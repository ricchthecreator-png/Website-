import { useEffect, useMemo, useState } from "react";
import type { ReactNode } from "react";
import {
  AGES,
  REGIONS,
  TYPES,
  YEARS,
  aggregate,
  fmtMoney,
  fmtMoneyFull,
  fmtNum,
  fmtPct,
  previousFilters,
  trendOf,
} from "../lib/data";
import type { Filters } from "../lib/data";
import { AreaLineChart, DonutChart, LegendList, RankBars, Sparkline } from "./Charts";
import { useCountUp, useReveal } from "../lib/hooks";
import { Seal } from "./Seal";

type SortKey = "year" | "typeLabel" | "complaints" | "losses" | "median" | "recovered" | "rate" | "yoy";

const SORT_LABELS: Record<SortKey, string> = {
  year: "Year",
  typeLabel: "Category",
  complaints: "Complaints",
  losses: "Reported loss",
  median: "Median loss",
  recovered: "Recovered",
  rate: "Recovery rate",
  yoy: "YoY",
};

function Trend({ value, invert = false }: { value: number; invert?: boolean }) {
  const up = value >= 0;
  const good = invert ? !up : up;
  return (
    <span
      className={`num inline-flex items-center gap-1 text-[11px] font-medium ${
        good ? "text-forest dark:text-sage" : "text-oxblood dark:text-rose"
      }`}
    >
      <span aria-hidden="true">{up ? "▲" : "▼"}</span>
      {Math.abs(value * 100).toFixed(1)}%
    </span>
  );
}

function KpiCell({
  label,
  value,
  format,
  trend,
  invert,
  spark,
  color,
  note,
  big = false,
  className,
}: {
  label: string;
  value: number;
  format: (n: number) => string;
  trend: number;
  invert?: boolean;
  spark: number[];
  color: string;
  note: string;
  big?: boolean;
  className?: string;
}) {
  const animated = useCountUp(value);
  return (
    <div className={`flex flex-col justify-between bg-paper px-5 py-5 dark:bg-micro ${className ?? ""}`}>
      <div className="tracked text-[9px] font-semibold text-warm dark:text-bone/55">{label}</div>
      <div className="mt-3 flex items-end gap-2">
        <div
          className={`num font-semibold leading-none tracking-tight text-ink dark:text-bone ${
            big ? "text-[34px] sm:text-[38px]" : "text-[26px]"
          }`}
        >
          {format(animated)}
        </div>
        <div className="mb-1">
          <Trend value={trend} invert={invert} />
        </div>
      </div>
      <div className="mt-1 text-[10px] text-warm dark:text-bone/45">{note}</div>
      <div className="mt-3 opacity-80">
        <Sparkline data={spark} color={color} height={26} />
      </div>
    </div>
  );
}

function Field({
  label,
  children,
}: {
  label: string;
  children: ReactNode;
}) {
  return (
    <label className="block">
      <span className="tracked block text-[9px] font-semibold text-warm dark:text-bone/55">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

const selectClass =
  "h-9 w-full appearance-none border border-ink/20 bg-paper px-2.5 pr-7 text-[12px] font-medium text-ink transition-colors hover:border-ink/45 dark:border-bone/20 dark:bg-micro2 dark:text-bone dark:hover:border-bone/45";

export function Dashboard() {
  const [filters, setFilters] = useState<Filters>({
    from: 2019,
    to: 2025,
    type: "all",
    region: "all",
    age: "all",
  });
  const [metric, setMetric] = useState<"loss" | "complaints">("loss");
  const [dim, setDim] = useState<"type" | "age" | "region">("type");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({ key: "losses", dir: "desc" });
  const [page, setPage] = useState(0);

  const agg = useMemo(() => aggregate(filters), [filters]);
  const prev = useMemo(() => aggregate(previousFilters(filters)), [filters]);
  const headRef = useReveal<HTMLDivElement>();

  useEffect(() => {
    setPage(0);
  }, [filters, search]);

  const set = (patch: Partial<Filters>) => setFilters((f) => ({ ...f, ...patch }));

  const rows = useMemo(() => {
    const q = search.trim().toLowerCase();
    const filtered = q
      ? agg.rows.filter(
          (r) =>
            r.typeLabel.toLowerCase().includes(q) ||
            String(r.year).includes(q) ||
            (q === "bec" && r.type === "bec"),
        )
      : agg.rows;
    const dir = sort.dir === "asc" ? 1 : -1;
    return [...filtered].sort((a, b) => {
      const va = a[sort.key as keyof typeof a];
      const vb = b[sort.key as keyof typeof b];
      if (typeof va === "string" && typeof vb === "string") return va.localeCompare(vb) * dir;
      return ((va as number) - (vb as number)) * dir;
    });
  }, [agg, search, sort]);

  const pageSize = 10;
  const pageCount = Math.max(1, Math.ceil(rows.length / pageSize));
  const pageRows = rows.slice(page * pageSize, page * pageSize + pageSize);

  const toggleSort = (key: SortKey) =>
    setSort((s) => (s.key === key ? { key, dir: s.dir === "asc" ? "desc" : "asc" } : { key, dir: "desc" }));

  const donutItems = useMemo(() => {
    if (dim === "type") {
      const top = agg.byType.slice(0, 5).map((t) => ({
        key: t.key,
        label: t.label,
        value: t.value,
        color: t.color,
        share: t.share,
      }));
      const rest = agg.byType.slice(5);
      const restValue = rest.reduce((a, t) => a + t.value, 0);
      return restValue > 0
        ? [
            ...top,
            {
              key: "other",
              label: "All other categories",
              value: restValue,
              color: "#6e6a60",
              share: rest.reduce((a, t) => a + t.share, 0),
            },
          ]
        : top;
    }
    if (dim === "age")
      return agg.byAge.map((a) => ({
        key: a.key,
        label: a.label,
        value: a.value,
        color: ageColor(a.key),
        share: a.share,
      }));
    return agg.byRegion.map((r) => ({
      key: r.key,
      label: r.label,
      value: r.value,
      color: regionColor(r.key),
      share: r.share,
    }));
  }, [agg, dim]);

  const recoveryRank = useMemo(
    () =>
      agg.byType
        .map((t) => ({ ...t, value: t.value > 0 ? t.recovered / t.value : 0 }))
        .sort((a, b) => b.value - a.value)
        .slice(0, 6),
    [agg],
  );

  const trendComplaints = trendOf(agg.complaints, prev.complaints);
  const trendLosses = trendOf(agg.losses, prev.losses);
  const trendRecovered = trendOf(agg.recovered, prev.recovered);
  const trendRate = trendOf(agg.recoveryRate, prev.recoveryRate);
  const trendMedian = trendOf(agg.medianLoss, prev.medianLoss);

  const rangeLabel = `${filters.from}–${filters.to}`;
  const segmentLabel =
    (filters.type === "all" ? "All categories" : TYPES.find((t) => t.key === filters.type)?.label) +
    (filters.region !== "all" ? ` · ${REGIONS.find((r) => r.key === filters.region)?.label}` : "") +
    (filters.age !== "all" ? ` · ${AGES.find((a) => a.key === filters.age)?.label}` : "");

  return (
    <section id="data" className="relative">
      {/* ---------------- filter bar ---------------- */}
      <div className="z-30 border-y border-ink/15 bg-paper/95 backdrop-blur-sm lg:sticky lg:top-0 dark:border-microrule dark:bg-micro/95">
        <div className="mx-auto max-w-[1400px] px-5 py-3.5 sm:px-8">
          <div className="flex flex-wrap items-end gap-x-5 gap-y-3">
            <Field label="Reporting period">
              <div className="flex items-center gap-1.5">
                <select
                  value={filters.from}
                  onChange={(e) => set({ from: Math.min(Number(e.target.value), filters.to) })}
                  className={`${selectClass} num w-[86px]`}
                  aria-label="From year"
                >
                  {YEARS.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
                <span className="text-warm dark:text-bone/45">–</span>
                <select
                  value={filters.to}
                  onChange={(e) => set({ to: Math.max(Number(e.target.value), filters.from) })}
                  className={`${selectClass} num w-[86px]`}
                  aria-label="To year"
                >
                  {YEARS.map((y) => (
                    <option key={y} value={y}>
                      {y}
                    </option>
                  ))}
                </select>
              </div>
            </Field>

            <Field label="Crime category">
              <select
                value={filters.type}
                onChange={(e) => set({ type: e.target.value })}
                className={`${selectClass} w-[210px]`}
              >
                <option value="all">All categories</option>
                {TYPES.map((t) => (
                  <option key={t.key} value={t.key}>
                    {t.label}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Victim region">
              <select
                value={filters.region}
                onChange={(e) => set({ region: e.target.value })}
                className={`${selectClass} w-[150px]`}
              >
                <option value="all">All regions</option>
                {REGIONS.map((r) => (
                  <option key={r.key} value={r.key}>
                    {r.label}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Victim age band">
              <select
                value={filters.age}
                onChange={(e) => set({ age: e.target.value })}
                className={`${selectClass} w-[150px]`}
              >
                <option value="all">All ages</option>
                {AGES.map((a) => (
                  <option key={a.key} value={a.key}>
                    {a.label}
                  </option>
                ))}
              </select>
            </Field>

            <Field label="Ledger search">
              <input
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="category or year…"
                className="h-9 w-[170px] border border-ink/20 bg-paper px-2.5 text-[12px] text-ink placeholder:text-warm/70 hover:border-ink/45 dark:border-bone/20 dark:bg-micro2 dark:text-bone dark:placeholder:text-bone/35"
              />
            </Field>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() =>
                  setFilters({ from: 2023, to: 2025, type: "all", region: "all", age: "all" })
                }
                className="tracked h-9 border border-ink/20 px-3 text-[9px] font-semibold text-ink transition-colors hover:border-ink hover:bg-ink hover:text-paper dark:border-bone/20 dark:text-bone dark:hover:border-bone dark:hover:bg-bone dark:hover:text-micro"
              >
                Last 3 yrs
              </button>
              <button
                type="button"
                onClick={() => {
                  setFilters({ from: 2019, to: 2025, type: "all", region: "all", age: "all" });
                  setSearch("");
                }}
                className="tracked h-9 border border-goldink/60 bg-gold/10 px-3 text-[9px] font-semibold text-goldink transition-colors hover:bg-gold hover:text-paper dark:border-gold/60 dark:text-gold dark:hover:text-ink"
              >
                Reset
              </button>
            </div>
          </div>

          <div className="mt-2.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[10px] text-warm dark:text-bone/50">
            <span className="tracked font-semibold text-ink/70 dark:text-bone/60">Active view</span>
            <span className="num">
              {rangeLabel} · {segmentLabel}
            </span>
            <span className="text-gold">·</span>
            <span className="num">
              {fmtNum(agg.complaints)} complaints · {fmtMoney(agg.losses)} reported
            </span>
          </div>
        </div>
      </div>

      {/* ---------------- KPI ledger band ---------------- */}
      <div ref={headRef} className="reveal mx-auto max-w-[1400px] px-5 pt-10 sm:px-8">
        <div className="flex flex-wrap items-baseline justify-between gap-3 border-b-2 border-ink pb-2 dark:border-bone/70">
          <h2 className="font-serif text-[26px] leading-none font-light text-ink sm:text-[34px] dark:text-bone">
            Commission ledger <span className="italic text-goldink dark:text-gold">— summary of record</span>
          </h2>
          <div className="num text-[10px] text-warm dark:text-bone/50">
            COMPARISON WINDOW · {previousFilters(filters).from}–{previousFilters(filters).to} · UPDATED 06:00 UTC
          </div>
        </div>

        <div className="grid grid-cols-1 gap-px border border-rule bg-rule sm:grid-cols-2 lg:grid-cols-5 dark:border-microrule dark:bg-microrule">
          <KpiCell
            label="Complaints filed"
            value={agg.complaints}
            format={fmtNum}
            trend={trendComplaints}
            spark={agg.monthly.map((m) => m.secondary)}
            color="#43536a"
            note="public reports received"
          />
          <KpiCell
            label="Reported losses"
            value={agg.losses}
            format={(n) => fmtMoney(n)}
            trend={trendLosses}
            invert
            spark={agg.monthly.map((m) => m.value)}
            color="#9e2b25"
            note="verified financial harm"
            big
          />
          <KpiCell
            label="Funds recovered"
            value={agg.recovered}
            format={(n) => fmtMoney(n)}
            trend={trendRecovered}
            spark={agg.monthly.map((m) => m.tertiary)}
            color="#2f6b4f"
            note="traced & returned to victims"
            big
          />
          <KpiCell
            label="Recovery rate"
            value={agg.recoveryRate}
            format={(n) => fmtPct(n)}
            trend={trendRate}
            spark={agg.monthly.map((m) => (m.value ? m.tertiary / m.value : 0))}
            color="#b08328"
            note="share of losses repatriated"
          />
          <KpiCell
            label="Median loss / victim"
            value={agg.medianLoss}
            format={fmtMoneyFull}
            trend={trendMedian}
            invert
            spark={agg.monthly.map((m) => (m.secondary ? (m.value / m.secondary) * 0.42 : 0))}
            color="#0f2440"
            note={`mean loss ${fmtMoneyFull(agg.avgLoss)}`}
            className="sm:col-span-2 lg:col-span-1"
          />
        </div>
      </div>

      {/* ---------------- charts ---------------- */}
      <div className="mx-auto max-w-[1400px] px-5 pt-12 sm:px-8">
        <div className="grid grid-cols-1 gap-px bg-rule lg:grid-cols-12 dark:bg-microrule">
          {/* line chart */}
          <div className="bg-paper p-5 sm:p-7 lg:col-span-7 dark:bg-micro">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="tracked text-[9px] font-semibold text-goldink dark:text-gold">Exhibit A</div>
                <h3 className="mt-1 font-serif text-[21px] leading-tight text-ink dark:text-bone">
                  {metric === "loss" ? "Reported losses" : "Complaint volume"} by month
                </h3>
                <p className="mt-1 max-w-[46ch] text-[11px] leading-relaxed text-warm dark:text-bone/50">
                  Monthly totals for the active view. Hover the rule to read any period against the one before it.
                </p>
              </div>
              <div className="flex border border-ink/20 dark:border-bone/20">
                {(["loss", "complaints"] as const).map((m) => (
                  <button
                    key={m}
                    type="button"
                    onClick={() => setMetric(m)}
                    className={`tracked px-3 py-2 text-[9px] font-semibold transition-colors ${
                      metric === m
                        ? "bg-ink text-paper dark:bg-bone dark:text-micro"
                        : "text-ink hover:bg-paper2 dark:text-bone/70 dark:hover:bg-micro2"
                    }`}
                  >
                    {m === "loss" ? "Losses" : "Complaints"}
                  </button>
                ))}
              </div>
            </div>
            <div className="mt-6">
              <AreaLineChart
                data={agg.monthly}
                metric={metric}
                color={metric === "loss" ? "#9e2b25" : "#0f2440"}
                format={metric === "loss" ? (n) => fmtMoney(n) : (n) => fmtNum(n)}
                height={300}
              />
            </div>
            <div className="mt-8 grid grid-cols-2 gap-4 border-t border-rule pt-4 sm:grid-cols-4 dark:border-microrule">
              {[
                { k: "Peak month", v: peakMonth(agg.monthly, metric) },
                { k: "Months reported", v: fmtNum(agg.monthly.length) },
                { k: "Avg / month", v: avgMonth(agg.monthly, metric) },
                { k: "Volatility", v: volatility(agg.monthly, metric) },
              ].map((s) => (
                <div key={s.k}>
                  <div className="tracked text-[9px] text-warm dark:text-bone/50">{s.k}</div>
                  <div className="num mt-1 text-[13px] font-semibold text-ink dark:text-bone">{s.v}</div>
                </div>
              ))}
            </div>
          </div>

          {/* donut */}
          <div className="bg-paper p-5 sm:p-7 lg:col-span-5 dark:bg-micro">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="tracked text-[9px] font-semibold text-goldink dark:text-gold">Exhibit B</div>
                <h3 className="mt-1 font-serif text-[21px] leading-tight text-ink dark:text-bone">
                  Where the money went
                </h3>
              </div>
              <div className="flex flex-wrap gap-1.5">
                {(
                  [
                    ["type", "Category"],
                    ["age", "Age"],
                    ["region", "Region"],
                  ] as const
                ).map(([k, label]) => (
                  <button
                    key={k}
                    type="button"
                    onClick={() => setDim(k)}
                    className={`tracked border px-2.5 py-1.5 text-[9px] font-semibold transition-colors ${
                      dim === k
                        ? "border-gold bg-gold text-paper dark:text-ink"
                        : "border-ink/20 text-ink hover:border-ink/50 dark:border-bone/20 dark:text-bone/70"
                    }`}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>

            <div className="mt-5">
              <DonutChart
                items={donutItems}
                format={(n) => fmtMoney(n)}
                centerLabel="Total reported loss"
                centerValue={fmtMoney(agg.losses)}
              />
            </div>
            <LegendList items={donutItems} format={(n) => fmtMoney(n)} />
          </div>

          {/* ranked bars */}
          <div className="bg-paper p-5 sm:p-7 lg:col-span-7 dark:bg-micro">
            <div className="flex flex-wrap items-start justify-between gap-3">
              <div>
                <div className="tracked text-[9px] font-semibold text-goldink dark:text-gold">Exhibit C</div>
                <h3 className="mt-1 font-serif text-[21px] leading-tight text-ink dark:text-bone">
                  Loss by crime category
                </h3>
                <p className="mt-1 max-w-[52ch] text-[11px] leading-relaxed text-warm dark:text-bone/50">
                  Select a row to filter every exhibit and the ledger below. Select it again to clear.
                </p>
              </div>
              {filters.type !== "all" && (
                <button
                  type="button"
                  onClick={() => set({ type: "all" })}
                  className="tracked border border-goldink/60 px-2.5 py-1.5 text-[9px] font-semibold text-goldink transition-colors hover:bg-gold hover:text-paper dark:border-gold/60 dark:text-gold dark:hover:text-ink"
                >
                  Clear category filter
                </button>
              )}
            </div>
            <div className="mt-4">
              <RankBars
                items={agg.byType.slice(0, 8)}
                active={filters.type}
                onSelect={(k) => set({ type: k })}
                format={(n) => fmtMoney(n)}
              />
            </div>
          </div>

          {/* recovery efficiency */}
          <div className="bg-paper p-5 sm:p-7 lg:col-span-5 dark:bg-micro">
            <div className="tracked text-[9px] font-semibold text-goldink dark:text-gold">Exhibit D</div>
            <h3 className="mt-1 font-serif text-[21px] leading-tight text-ink dark:text-bone">
              Recovery efficiency
            </h3>
            <p className="mt-1 text-[11px] leading-relaxed text-warm dark:text-bone/50">
              Share of losses traced, frozen and returned — by category, active view.
            </p>
            <div className="mt-4">
              <RankBars
                items={recoveryRank}
                active=""
                onSelect={() => undefined}
                format={(n) => fmtPct(n)}
              />
            </div>
            <div className="mt-5 border-t border-rule pt-4 dark:border-microrule">
              <p className="font-serif text-[15px] leading-relaxed text-ink italic dark:text-bone/85">
                “Wire recall windows close in 72 hours. The first complaint filed is the one that gets the money
                back.”
              </p>
              <div className="tracked mt-2 text-[9px] text-warm dark:text-bone/50">
                — Asset Recovery Division, operating manual §2.1
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* ---------------- data table ---------------- */}
      <div className="mt-16 border-y border-ink/15 bg-paper2/60 py-12 dark:border-microrule dark:bg-micro2/30">
        <div className="mx-auto max-w-[1400px] px-5 sm:px-8">
          <div className="flex flex-wrap items-end justify-between gap-4">
            <div>
              <div className="tracked text-[9px] font-semibold text-goldink dark:text-gold">Appendix I</div>
              <h2 className="mt-1 font-serif text-[28px] leading-none text-ink sm:text-[36px] dark:text-bone">
                Complaint &amp; recovery ledger
              </h2>
              <p className="mt-2 max-w-[60ch] text-[12px] leading-relaxed text-warm dark:text-bone/55">
                Every category-year entry in the active view. Sort any column, search the ledger, or select a row to
                filter the exhibits above.
              </p>
            </div>
            <div className="num text-[10px] text-warm dark:text-bone/50">
              {fmtNum(rows.length)} ENTRIES · PAGE {page + 1} OF {pageCount}
            </div>
          </div>

          <div className="mt-6 overflow-x-auto border border-rule bg-paper dark:border-microrule dark:bg-micro">
            <table className="w-full min-w-[860px] border-collapse text-left">
              <thead>
                <tr className="border-b-2 border-ink dark:border-bone/70">
                  {(Object.keys(SORT_LABELS) as SortKey[]).map((k) => {
                    const active = sort.key === k;
                    return (
                      <th key={k} scope="col" className="px-3 py-3 first:pl-4 last:pr-4">
                        <button
                          type="button"
                          onClick={() => toggleSort(k)}
                          className={`tracked flex w-full items-center gap-1 text-[9px] font-semibold transition-colors hover:text-gold ${
                            k === "year" || k === "typeLabel" ? "justify-start" : "justify-end"
                          } ${active ? "text-goldink dark:text-gold" : "text-ink dark:text-bone/75"}`}
                        >
                          {SORT_LABELS[k]}
                          <span className="num text-[8px] opacity-70">
                            {active ? (sort.dir === "asc" ? "▲" : "▼") : "◇"}
                          </span>
                        </button>
                      </th>
                    );
                  })}
                </tr>
              </thead>
              <tbody>
                {pageRows.map((r, i) => (
                  <tr
                    key={r.id}
                    onClick={() => set({ type: r.type, from: r.year, to: r.year })}
                    className={`group cursor-pointer border-b border-rule transition-colors last:border-b-0 hover:bg-gold/10 dark:border-microrule dark:hover:bg-gold/15 ${
                      i % 2 === 1 ? "bg-paper2/40 dark:bg-micro2/40" : ""
                    }`}
                  >
                    <td className="num px-3 py-2.5 pl-4 text-[12px] text-warm dark:text-bone/60">{r.year}</td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center gap-2">
                        <span className="h-2.5 w-2.5 shrink-0" style={{ background: r.color }} />
                        <span className="text-[12px] font-medium text-ink dark:text-bone">{r.typeLabel}</span>
                      </div>
                    </td>
                    <td className="num px-3 py-2.5 text-right text-[12px] text-ink dark:text-bone">
                      {fmtNum(r.complaints)}
                    </td>
                    <td className="num px-3 py-2.5 text-right text-[12px] font-semibold text-oxblood dark:text-rose">
                      {fmtMoney(r.losses)}
                    </td>
                    <td className="num px-3 py-2.5 text-right text-[12px] text-ink dark:text-bone">
                      {fmtMoneyFull(r.median)}
                    </td>
                    <td className="num px-3 py-2.5 text-right text-[12px] font-semibold text-forest dark:text-sage">
                      {fmtMoney(r.recovered)}
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="flex items-center justify-end gap-2">
                        <div className="h-[6px] w-16 bg-rule dark:bg-microrule">
                          <div
                            className="h-full bg-gold transition-[width] duration-700"
                            style={{ width: `${Math.min(100, r.rate * 220)}%` }}
                          />
                        </div>
                        <span className="num w-12 text-right text-[11px] text-ink dark:text-bone">
                          {fmtPct(r.rate)}
                        </span>
                      </div>
                    </td>
                    <td className="px-3 py-2.5 pr-4 text-right">
                      {r.yoy === 0 ? (
                        <span className="num text-[11px] text-warm dark:text-bone/45">—</span>
                      ) : (
                        <Trend value={r.yoy} invert />
                      )}
                    </td>
                  </tr>
                ))}
                {pageRows.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-6 py-16 text-center">
                      <div className="mx-auto flex max-w-[380px] flex-col items-center">
                        <div className="opacity-25">
                          <Seal size={64} ink="currentColor" gold="currentColor" />
                        </div>
                        <div className="tracked mt-4 text-[10px] font-semibold text-ink dark:text-bone">
                          No ledger entries match this query
                        </div>
                        <p className="mt-2 text-[12px] leading-relaxed text-warm dark:text-bone/55">
                          The search “{search}” returned nothing in the active view. Clear it, or widen the reporting
                          period.
                        </p>
                        <button
                          type="button"
                          onClick={() => {
                            setSearch("");
                            setFilters({ from: 2019, to: 2025, type: "all", region: "all", age: "all" });
                          }}
                          className="tracked mt-5 border border-ink px-4 py-2 text-[9px] font-semibold text-ink transition-colors hover:bg-ink hover:text-paper dark:border-bone/60 dark:text-bone dark:hover:bg-bone dark:hover:text-micro"
                        >
                          Reset the ledger
                        </button>
                      </div>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
            <div className="num text-[10px] text-warm dark:text-bone/50">
              SHOWING {rows.length === 0 ? 0 : page * pageSize + 1}–
              {Math.min(rows.length, (page + 1) * pageSize)} OF {fmtNum(rows.length)}
            </div>
            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={() => setPage((p) => Math.max(0, p - 1))}
                disabled={page === 0}
                className="tracked border border-ink/20 px-3 py-2 text-[9px] font-semibold text-ink transition-colors hover:border-ink disabled:cursor-not-allowed disabled:opacity-35 dark:border-bone/20 dark:text-bone dark:hover:border-bone"
              >
                Previous
              </button>
              {Array.from({ length: pageCount }).slice(0, 9).map((_, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setPage(i)}
                  className={`num h-[34px] w-[34px] border text-[11px] transition-colors ${
                    page === i
                      ? "border-ink bg-ink text-paper dark:border-bone dark:bg-bone dark:text-micro"
                      : "border-ink/20 text-ink hover:border-ink dark:border-bone/20 dark:text-bone dark:hover:border-bone"
                  }`}
                >
                  {i + 1}
                </button>
              ))}
              <button
                type="button"
                onClick={() => setPage((p) => Math.min(pageCount - 1, p + 1))}
                disabled={page >= pageCount - 1}
                className="tracked border border-ink/20 px-3 py-2 text-[9px] font-semibold text-ink transition-colors hover:border-ink disabled:cursor-not-allowed disabled:opacity-35 dark:border-bone/20 dark:text-bone dark:hover:border-bone"
              >
                Next
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

function ageColor(key: string) {
  const map: Record<string, string> = {
    u20: "#c2652f",
    "20s": "#b08328",
    "30s": "#0f2440",
    "40s": "#4a6b8a",
    "50s": "#9e2b25",
    "60plus": "#2f6b4f",
  };
  return map[key] ?? "#6e6a60";
}

function regionColor(key: string) {
  const map: Record<string, string> = {
    northeast: "#0f2440",
    south: "#9e2b25",
    midwest: "#b08328",
    west: "#4a6b8a",
    international: "#2f6b4f",
  };
  return map[key] ?? "#6e6a60";
}

function peakMonth(monthly: { label: string; value: number; secondary: number }[], metric: "loss" | "complaints") {
  if (!monthly.length) return "—";
  const key = metric === "loss" ? "value" : "secondary";
  const peak = monthly.reduce((a, b) => (b[key] > a[key] ? b : a));
  return `${peak.label} · ${metric === "loss" ? fmtMoney(peak.value) : fmtNum(peak.secondary)}`;
}

function avgMonth(monthly: { label: string; value: number; secondary: number }[], metric: "loss" | "complaints") {
  if (!monthly.length) return "—";
  const vals = monthly.map((m) => (metric === "loss" ? m.value : m.secondary));
  const avg = vals.reduce((a, b) => a + b, 0) / vals.length;
  return metric === "loss" ? fmtMoney(avg) : fmtNum(avg);
}

function volatility(monthly: { label: string; value: number; secondary: number }[], metric: "loss" | "complaints") {
  if (monthly.length < 2) return "—";
  const vals = monthly.map((m) => (metric === "loss" ? m.value : m.secondary));
  const mean = vals.reduce((a, b) => a + b, 0) / vals.length;
  const sd = Math.sqrt(vals.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / vals.length);
  return `±${((sd / mean) * 100).toFixed(1)}%`;
}
