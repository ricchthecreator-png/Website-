import { useState } from "react";
import type { FormEvent } from "react";
import { TYPES, fmtMoney } from "../lib/data";
import { RecoveredStamp, Seal } from "./Seal";
import { useReveal } from "../lib/hooks";

const CASE_FILES = [
  {
    id: "CF-2025-04188",
    type: "Investment fraud · crypto corridor",
    route: "Singapore → Hong Kong → Latvia",
    frozen: 4_200_000,
    returned: 3_140_000,
    victims: 142,
    days: 88,
    status: "Restitution complete",
  },
  {
    id: "CF-2025-07712",
    type: "Business email compromise",
    route: "United States → Mexico → Nigeria",
    frozen: 1_860_000,
    returned: 1_402_000,
    victims: 9,
    days: 41,
    status: "Restitution complete",
  },
  {
    id: "CF-2026-00231",
    type: "Tech support fraud · elder target",
    route: "Canada → India → United Kingdom",
    frozen: 742_000,
    returned: 318_000,
    victims: 63,
    days: 112,
    status: "Partial recovery",
  },
];

const STEPS = [
  {
    n: "01",
    title: "Intake & tracing",
    body: "A filed complaint is matched against payment rails within 24 hours. Our tracers follow wire references, mule account chains and blockchain heuristics until the funds land somewhere with a legal name attached.",
    meta: "Median 26 hours to first trace",
  },
  {
    n: "02",
    title: "Preservation & legal action",
    body: "Where funds are still in reach, we file preservation notices, freezing orders and mutual legal assistance requests through the Commission's 41-jurisdiction network. The 72-hour wire recall window is the whole game.",
    meta: "41 jurisdictions · 214 partner institutions",
  },
  {
    n: "03",
    title: "Repatriation & settlement",
    body: "Recovered money is reconciled against the ledger of verified victims, then returned pro rata. Every case closes with a public accounting entry — including the ones that recover nothing.",
    meta: "Median 96 days from filing to restitution",
  },
];

export function Recovery() {
  const headRef = useReveal<HTMLDivElement>();
  const [form, setForm] = useState({
    name: "",
    email: "",
    category: TYPES[0].key,
    amount: "",
    narrative: "",
  });
  const [caseNo, setCaseNo] = useState<string | null>(null);

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setCaseNo(`ICCC-2026-${String(Math.floor(Math.random() * 90000) + 10000)}`);
  };

  const inputClass =
    "w-full border border-bone/25 bg-transparent px-3 py-2.5 text-[13px] text-bone placeholder:text-bone/35 transition-colors focus:border-gold";

  return (
    <section id="recovery" className="relative bg-ink text-bone">
      {/* full-bleed archive band */}
      <div className="relative h-[320px] w-full overflow-hidden sm:h-[420px]">
        <img
          src="images/archive.jpg"
          alt="Government records room: rows of archive boxes and bound ledgers on steel shelving"
          className="h-full w-full object-cover object-center"
          loading="lazy"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/70 to-ink/25" />
        <div className="absolute inset-x-0 bottom-0 mx-auto max-w-[1400px] px-5 pb-8 sm:px-8">
          <div ref={headRef} className="reveal">
            <div className="tracked text-[9px] font-semibold text-gold">
              Asset Recovery Division · Bureau of Repatriation
            </div>
            <h2 className="mt-3 max-w-[18ch] font-serif text-[36px] leading-[0.98] font-light sm:text-[62px]">
              We follow the money <span className="italic text-gold">until it comes home.</span>
            </h2>
          </div>
        </div>
      </div>

      {/* intro + stats */}
      <div className="mx-auto max-w-[1400px] px-5 pt-12 sm:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12">
          <div className="lg:col-span-6">
            <p className="font-serif text-[19px] leading-[1.6] text-bone/90 sm:text-[22px]">
              Reporting a crime is the beginning of the file, not the end of it. The Commission was built to do the
              part that victims are almost never told is possible: trace what was taken, freeze it before it moves
              again, and hand it back.
            </p>
            <p className="mt-5 max-w-[62ch] text-[13px] leading-[1.85] text-bone/65">
              We work alongside national fraud agencies, correspondent banks and virtual asset service providers in 41
              jurisdictions. There is no fee to open a case, no percentage taken from what is returned, and no
              guarantee — roughly one dollar in five that enters our tracing queue is recovered in full or in part.
              Anyone promising you certainty is running a recovery scam on top of the first one.
            </p>
          </div>

          <div className="lg:col-span-6">
            <div className="grid grid-cols-2 gap-px border border-bone/15 bg-bone/15">
              {[
                { k: "Recovered since 2019", v: "$1.94B" },
                { k: "Cases worked", v: "12,480" },
                { k: "Jurisdictions", v: "41" },
                { k: "Median time to restitution", v: "96 days" },
                { k: "Partner institutions", v: "214" },
                { k: "Fee to victims", v: "$0" },
              ].map((s) => (
                <div key={s.k} className="bg-ink px-5 py-6">
                  <div className="num text-[26px] leading-none font-semibold text-gold sm:text-[32px]">{s.v}</div>
                  <div className="tracked mt-2 text-[9px] text-bone/55">{s.k}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* process */}
        <div className="mt-16">
          <div className="tracked text-[9px] font-semibold text-gold">Operating procedure</div>
          <div className="mt-6 grid grid-cols-1 gap-px bg-bone/15 lg:grid-cols-3">
            {STEPS.map((s) => (
              <div key={s.n} className="bg-ink p-6 sm:p-8">
                <div className="num text-[46px] leading-none font-semibold text-bone/20">{s.n}</div>
                <h3 className="mt-4 font-serif text-[23px] leading-tight text-bone">{s.title}</h3>
                <p className="mt-3 text-[12.5px] leading-[1.85] text-bone/65">{s.body}</p>
                <div className="tracked mt-5 border-t border-bone/15 pt-3 text-[9px] text-gold">{s.meta}</div>
              </div>
            ))}
          </div>
        </div>

        {/* case files */}
        <div className="mt-16">
          <div className="flex flex-wrap items-end justify-between gap-3 border-b border-bone/20 pb-3">
            <h3 className="font-serif text-[26px] leading-none text-bone sm:text-[32px]">
              Selected case files <span className="italic text-gold">— closed & active</span>
            </h3>
            <div className="num text-[10px] text-bone/50">PUBLIC ACCOUNTING EXTRACT · Q1 2026</div>
          </div>

          <div className="mt-6 grid grid-cols-1 gap-px bg-bone/15 lg:grid-cols-3">
            {CASE_FILES.map((c) => (
              <article key={c.id} className="relative overflow-hidden bg-ink p-6 sm:p-7">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <div className="num text-[11px] tracking-wider text-gold">{c.id}</div>
                    <h4 className="mt-2 text-[15px] leading-snug font-semibold text-bone">{c.type}</h4>
                    <div className="mt-1 text-[11px] text-bone/55">{c.route}</div>
                  </div>
                  <RecoveredStamp
                    label={c.status === "Partial recovery" ? "Partial" : "Recovered"}
                    className="shrink-0 opacity-80"
                  />
                </div>

                <dl className="mt-6 space-y-2.5">
                  {[
                    { k: "Frozen on trace", v: fmtMoney(c.frozen), cls: "text-bone" },
                    { k: "Returned to victims", v: fmtMoney(c.returned), cls: "text-gold" },
                    { k: "Verified victims", v: String(c.victims), cls: "text-bone" },
                    { k: "Days to restitution", v: String(c.days), cls: "text-bone" },
                  ].map((row) => (
                    <div
                      key={row.k}
                      className="flex items-baseline justify-between gap-3 border-b border-dotted border-bone/15 pb-2"
                    >
                      <dt className="tracked text-[9px] text-bone/55">{row.k}</dt>
                      <dd className={`num text-[13px] font-semibold ${row.cls}`}>{row.v}</dd>
                    </div>
                  ))}
                </dl>

                <div className="mt-4">
                  <div className="h-[6px] w-full bg-bone/15">
                    <div
                      className="h-full bg-gold transition-[width] duration-1000"
                      style={{ width: `${Math.round((c.returned / c.frozen) * 100)}%` }}
                    />
                  </div>
                  <div className="num mt-2 text-[10px] text-bone/50">
                    {Math.round((c.returned / c.frozen) * 100)}% of frozen value repatriated
                  </div>
                </div>
              </article>
            ))}
          </div>
        </div>

        {/* intake form */}
        <div id="intake" className="mt-20 mb-20">
          <div className="grid grid-cols-1 gap-px bg-bone/15 lg:grid-cols-12">
            <div className="bg-ink p-8 sm:p-10 lg:col-span-5">
              <div className="tracked text-[9px] font-semibold text-gold">Open a case</div>
              <h3 className="mt-3 font-serif text-[30px] leading-[1.05] text-bone sm:text-[40px]">
                If the money is still moving, <span className="italic text-gold">so are we.</span>
              </h3>
              <p className="mt-5 text-[12.5px] leading-[1.85] text-bone/65">
                File the details below and a tracing officer is assigned within one business day. Bring whatever you
                have: wire references, wallet addresses, message logs, the name the scammer used. Nothing is too small
                to be useful.
              </p>
              <div className="mt-8 flex items-start gap-4 border-t border-bone/15 pt-6">
                <Seal size={54} ink="#ede7da" gold="#b08328" className="shrink-0" />
                <p className="text-[11px] leading-relaxed text-bone/55">
                  The Commission never asks for payment, gift cards or cryptocurrency to release recovered funds. Any
                  communication that does is fraudulent — forward it to <span className="text-gold">fraud@iccc.gov</span>.
                </p>
              </div>
            </div>

            <div className="bg-ink p-8 sm:p-10 lg:col-span-7">
              {caseNo ? (
                <div className="flex h-full min-h-[380px] flex-col items-start justify-center">
                  <RecoveredStamp label="Case opened" className="scale-125 origin-left" />
                  <div className="num mt-8 text-[34px] leading-none font-semibold text-gold sm:text-[46px]">
                    {caseNo}
                  </div>
                  <p className="mt-5 max-w-[52ch] text-[13px] leading-[1.85] text-bone/70">
                    Your filing is in the queue. A tracing officer will contact{" "}
                    <span className="text-bone">{form.email || "you"}</span> within one business day. Keep this case
                    number — every update, preservation notice and restitution entry is filed against it.
                  </p>
                  <button
                    type="button"
                    onClick={() => {
                      setCaseNo(null);
                      setForm({ name: "", email: "", category: TYPES[0].key, amount: "", narrative: "" });
                    }}
                    className="tracked mt-8 border border-bone/30 px-5 py-3 text-[9px] font-semibold text-bone transition-colors hover:border-gold hover:text-gold"
                  >
                    File another complaint
                  </button>
                </div>
              ) : (
                <form onSubmit={submit} className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <label className="block">
                    <span className="tracked block text-[9px] text-bone/55">Full name</span>
                    <input
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      className={`${inputClass} mt-1.5`}
                      placeholder="Jane Okonkwo"
                    />
                  </label>
                  <label className="block">
                    <span className="tracked block text-[9px] text-bone/55">Email for case updates</span>
                    <input
                      required
                      type="email"
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      className={`${inputClass} mt-1.5`}
                      placeholder="jane@example.com"
                    />
                  </label>
                  <label className="block">
                    <span className="tracked block text-[9px] text-bone/55">Fraud category</span>
                    <select
                      value={form.category}
                      onChange={(e) => setForm({ ...form, category: e.target.value })}
                      className={`${inputClass} mt-1.5 appearance-none`}
                    >
                      {TYPES.map((t) => (
                        <option key={t.key} value={t.key} className="bg-ink">
                          {t.label}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label className="block">
                    <span className="tracked block text-[9px] text-bone/55">Amount lost (USD)</span>
                    <input
                      required
                      inputMode="decimal"
                      value={form.amount}
                      onChange={(e) => setForm({ ...form, amount: e.target.value })}
                      className={`${inputClass} num mt-1.5`}
                      placeholder="48,200"
                    />
                  </label>
                  <label className="block sm:col-span-2">
                    <span className="tracked block text-[9px] text-bone/55">
                      What happened — dates, accounts, wallet addresses, names used
                    </span>
                    <textarea
                      rows={4}
                      value={form.narrative}
                      onChange={(e) => setForm({ ...form, narrative: e.target.value })}
                      className={`${inputClass} mt-1.5 resize-none`}
                      placeholder="On 14 February I wired…"
                    />
                  </label>
                  <div className="flex flex-wrap items-center gap-4 sm:col-span-2">
                    <button
                      type="submit"
                      className="tracked border border-gold bg-gold px-6 py-3.5 text-[9px] font-semibold text-ink transition-colors hover:bg-transparent hover:text-gold"
                    >
                      Submit complaint for tracing
                    </button>
                    <span className="text-[10px] leading-relaxed text-bone/45">
                      Filing is free. We never sell, share or monetise complaint data.
                    </span>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
