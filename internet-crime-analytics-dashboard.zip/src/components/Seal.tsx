interface SealProps {
  size?: number;
  ink?: string;
  gold?: string;
  className?: string;
}

/**
 * Commission seal — drawn by hand as vector paths so it holds up at 16px,
 * reverses to a single colour and can be recoloured for dark mode.
 */
export function Seal({ size = 64, ink = "#0f2440", gold = "#b08328", className = "" }: SealProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      className={className}
      role="img"
      aria-label="Internet Crime Complaints Commission seal"
    >
      <defs>
        <path id="seal-arc-top" d="M 26,100 A 74,74 0 0 1 174,100" fill="none" />
        <path id="seal-arc-bottom" d="M 32,100 A 68,68 0 0 0 168,100" fill="none" />
      </defs>

      <circle cx="100" cy="100" r="97" fill="none" stroke={gold} strokeWidth="2" />
      <circle cx="100" cy="100" r="88" fill="none" stroke={ink} strokeWidth="1" opacity="0.55" />
      <circle cx="100" cy="100" r="58" fill="none" stroke={gold} strokeWidth="1" opacity="0.8" />

      <text
        fill={ink}
        fontFamily="Libre Franklin, sans-serif"
        fontSize="12.5"
        fontWeight="700"
        letterSpacing="2.6"
      >
        <textPath href="#seal-arc-top" startOffset="50%" textAnchor="middle">
          INTERNET CRIME COMPLAINTS
        </textPath>
      </text>
      <text
        fill={gold}
        fontFamily="Libre Franklin, sans-serif"
        fontSize="10"
        fontWeight="700"
        letterSpacing="2.2"
      >
        <textPath href="#seal-arc-bottom" startOffset="50%" textAnchor="middle">
          ★ COMMISSION · EST. 2000 ★
        </textPath>
      </text>

      {/* shield */}
      <path
        d="M100 56 L136 70 V106 C136 127 119 141 100 149 C81 141 64 127 64 106 V70 Z"
        fill="none"
        stroke={ink}
        strokeWidth="2.6"
        strokeLinejoin="round"
      />
      <path
        d="M100 63 L129 74 V105 C129 122 116 133 100 140 C84 133 71 122 71 105 V74 Z"
        fill={gold}
        opacity="0.18"
      />

      {/* scales of justice */}
      <path d="M100 74 V116" stroke={ink} strokeWidth="3.2" strokeLinecap="round" />
      <path d="M80 88 H120" stroke={ink} strokeWidth="3.2" strokeLinecap="round" />
      <circle cx="100" cy="71" r="3.6" fill={ink} />
      <path d="M80 90 L72 103 M80 90 L88 103 M120 90 L112 103 M120 90 L128 103" stroke={ink} strokeWidth="1.3" />
      <path d="M70 103 H90 A10 10 0 0 1 70 103 Z" fill={ink} />
      <path d="M110 103 H130 A10 10 0 0 1 110 103 Z" fill={ink} />

      {/* ledger rules under the balance */}
      <path d="M80 124 H120 M85 130 H115 M91 136 H109" stroke={ink} strokeWidth="1.3" opacity="0.65" />

      {/* rays */}
      <g stroke={gold} strokeWidth="1.2" opacity="0.75">
        <path d="M100 44 V36" />
        <path d="M62 56 L57 49" />
        <path d="M138 56 L143 49" />
      </g>
    </svg>
  );
}

/** Wordmark lockup used in the masthead and footer. */
export function Wordmark({
  ink = "#0f2440",
  accent = "#b08328",
  sub = "National Asset Recovery Bureau",
}: {
  ink?: string;
  accent?: string;
  sub?: string;
}) {
  return (
    <div className="leading-none">
      <div
        className="tracked text-[11px] font-extrabold sm:text-[13px]"
        style={{ color: ink }}
      >
        Internet Crime Complaints
      </div>
      <div
        className="tracked text-[11px] font-extrabold sm:text-[13px]"
        style={{ color: ink }}
      >
        Commission<span style={{ color: accent }}> · </span>
        <span className="tracked" style={{ color: accent, fontWeight: 600 }}>
          {sub}
        </span>
      </div>
    </div>
  );
}

/** Rubber-stamp mark used on recovered case files. */
export function RecoveredStamp({ label = "Recovered", className = "" }: { label?: string; className?: string }) {
  return (
    <div
      className={`stamp inline-flex select-none items-center border-[3px] border-oxblood/70 px-3 py-1 ${className}`}
      style={{ boxShadow: "inset 0 0 0 1px rgba(158,43,37,0.45)" }}
    >
      <span className="tracked text-[10px] font-extrabold text-oxblood/85">{label}</span>
    </div>
  );
}
