import { useEffect, useMemo, useRef, useState } from "react";
import type { MouseEvent as ReactMouseEvent } from "react";
import type { Point } from "../lib/data";



/* ------------------------------- sparkline ------------------------------- */

export function Sparkline({
  data,
  color,
  height = 30,
}: {
  data: number[];
  color: string;
  height?: number;
}) {
  const [drawn, setDrawn] = useState(false);
  useEffect(() => {
    const id = window.setTimeout(() => setDrawn(true), 60);
    return () => window.clearTimeout(id);
  }, []);
  const max = Math.max(...data, 1);
  const min = Math.min(...data, 0);
  const span = max - min || 1;
  const pts = data.map((v, i) => {
    const x = data.length > 1 ? (i / (data.length - 1)) * 100 : 0;
    const y = 28 - ((v - min) / span) * 24;
    return `${i === 0 ? "M" : "L"}${x.toFixed(2)},${y.toFixed(2)}`;
  });
  const d = pts.join(" ");
  return (
    <svg
      viewBox="0 0 100 30"
      preserveAspectRatio="none"
      style={{ height, width: "100%" }}
      aria-hidden="true"
    >
      <path
        d={`${d} L100,30 L0,30 Z`}
        fill={color}
        opacity={drawn ? 0.12 : 0}
        style={{ transition: "opacity .8s ease" }}
      />
      <path
        d={d}
        fill="none"
        stroke={color}
        strokeWidth={1.6}
        vectorEffect="non-scaling-stroke"
        strokeLinejoin="round"
        strokeLinecap="round"
        style={{
          strokeDasharray: 400,
          strokeDashoffset: drawn ? 0 : 400,
          transition: "stroke-dashoffset 1.1s cubic-bezier(.22,1,.36,1)",
        }}
      />
    </svg>
  );
}

/* ----------------------------- area line chart ---------------------------- */

export function AreaLineChart({
  data,
  metric,
  color,
  format,
  height = 300,
}: {
  data: Point[];
  metric: "loss" | "complaints";
  color: string;
  format: (n: number) => string;
  height?: number;
}) {
  const wrapRef = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState<number | null>(null);
  const [drawn, setDrawn] = useState(false);

  useEffect(() => {
    setDrawn(false);
    const id = window.setTimeout(() => setDrawn(true), 40);
    return () => window.clearTimeout(id);
  }, [metric, data.length]);

  const values = useMemo(
    () => data.map((d) => (metric === "loss" ? d.value : d.secondary)),
    [data, metric],
  );
  const n = values.length;
  const max = Math.max(...values, 1) * 1.15;

  const xAt = (i: number) => (n <= 1 ? 500 : (i / (n - 1)) * 1000);
  const yAt = (v: number) => 292 - (v / max) * 272;

  const linePath = values.map((v, i) => `${i === 0 ? "M" : "L"}${xAt(i).toFixed(1)},${yAt(v).toFixed(1)}`).join(" ");
  const areaPath = `${linePath} L1000,300 L0,300 Z`;

  const ticks = useMemo(() => {
    const count = Math.min(6, n);
    const out: number[] = [];
    for (let i = 0; i < count; i++) out.push(Math.round((i / (count - 1 || 1)) * (n - 1)));
    return Array.from(new Set(out));
  }, [n]);

  const onMove = (e: ReactMouseEvent<HTMLDivElement>) => {
    const el = wrapRef.current;
    if (!el) return;
    const rect = el.getBoundingClientRect();
    const rel = (e.clientX - rect.left) / rect.width;
    setHover(Math.max(0, Math.min(n - 1, Math.round(rel * (n - 1)))));
  };

  const hoverValue = hover !== null ? values[hover] : 0;
  const hoverPrev = hover !== null && hover > 0 ? values[hover - 1] : null;
  const delta = hoverPrev ? (hoverValue - hoverPrev) / hoverPrev : 0;

  return (
    <div
      ref={wrapRef}
      className="relative w-full cursor-crosshair select-none"
      style={{ height }}
      onMouseMove={onMove}
      onMouseLeave={() => setHover(null)}
      role="img"
      aria-label={`Time series of ${metric === "loss" ? "reported losses" : "complaints"}`}
    >
      <svg
        viewBox="0 0 1000 300"
        preserveAspectRatio="none"
        className="absolute inset-0 h-full w-full"
      >
        {[0, 0.25, 0.5, 0.75, 1].map((g) => (
          <line
            key={g}
            x1="0"
            x2="1000"
            y1={292 - g * 272}
            y2={292 - g * 272}
            stroke="currentColor"
            className="text-rule dark:text-microrule"
            strokeWidth={g === 0 ? 1.5 : 1}
            vectorEffect="non-scaling-stroke"
            strokeDasharray={g === 0 ? "0" : "2 5"}
          />
        ))}
        <path
          d={areaPath}
          fill={color}
          opacity={drawn ? 0.13 : 0}
          style={{ transition: "opacity 1s ease .25s" }}
        />
        <path
          d={linePath}
          fill="none"
          stroke={color}
          strokeWidth={2.2}
          strokeLinejoin="round"
          strokeLinecap="round"
          vectorEffect="non-scaling-stroke"
          style={{
            strokeDasharray: 6000,
            strokeDashoffset: drawn ? 0 : 6000,
            transition: "stroke-dashoffset 1.3s cubic-bezier(.22,1,.36,1)",
          }}
        />
        {hover !== null && (
          <line
            x1={xAt(hover)}
            x2={xAt(hover)}
            y1="8"
            y2="292"
            stroke={color}
            strokeWidth="1"
            strokeDasharray="3 4"
            vectorEffect="non-scaling-stroke"
            opacity="0.8"
          />
        )}
      </svg>

      {/* hover marker */}
      {hover !== null && (
        <div
          className="pointer-events-none absolute h-2.5 w-2.5 rounded-full border-2 border-paper dark:border-micro"
          style={{
            left: `${(xAt(hover) / 1000) * 100}%`,
            top: `${(yAt(hoverValue) / 300) * 100}%`,
            background: color,
            transform: "translate(-50%,-50%)",
          }}
        />
      )}

      {/* y-axis labels */}
      <div className="pointer-events-none absolute inset-y-0 left-0 flex w-full flex-col justify-between py-[2px] [&>*]:bg-paper/80 dark:[&>*]:bg-micro/80 [&>*]:pr-1.5">
        {[1, 0.75, 0.5, 0.25, 0].map((g) => (
          <div key={g} className="num text-[10px] text-warm dark:text-bone/45">
            {format(max * g)}
          </div>
        ))}
      </div>

      {/* x-axis labels */}
      <div className="pointer-events-none absolute inset-x-0 -bottom-1 h-5">
        {ticks.map((i) => (
          <div
            key={i}
            className="num absolute top-0 -translate-x-1/2 text-[10px] whitespace-nowrap text-warm dark:text-bone/45"
            style={{ left: `${(xAt(i) / 1000) * 100}%` }}
          >
            {data[i]?.label}
          </div>
        ))}
      </div>

      {/* tooltip */}
      {hover !== null && (
        <div
          className="pointer-events-none absolute z-20 min-w-[132px] border border-ink/25 bg-paper px-3 py-2 shadow-[0_10px_30px_-12px_rgba(15,36,64,.45)] dark:border-bone/20 dark:bg-micro2"
          style={{
            left: `${Math.min(88, Math.max(12, (xAt(hover) / 1000) * 100))}%`,
            top: "6px",
            transform: "translateX(-50%)",
          }}
        >
          <div className="tracked text-[9px] text-warm dark:text-bone/55">{data[hover]?.label}</div>
          <div className="num mt-1 text-[15px] font-semibold text-ink dark:text-bone">
            {format(hoverValue)}
          </div>
              {hoverPrev !== null && (
            <div
              className={`num text-[10px] ${delta >= 0 ? "text-forest dark:text-sage" : "text-oxblood dark:text-rose"}`}
            >
              {delta >= 0 ? "▲" : "▼"} {Math.abs(delta * 100).toFixed(1)}% vs prior period
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/* ------------------------------- rank bars ------------------------------- */

export function RankBars({
  items,
  active,
  onSelect,
  format,
}: {
  items: { key: string; label: string; value: number; color: string; share: number }[];
  active: string;
  onSelect: (key: string) => void;
  format: (n: number) => string;
}) {
  const [hover, setHover] = useState<string | null>(null);
  const max = Math.max(...items.map((i) => i.value), 1);
  return (
    <div className="flex flex-col">
      {items.map((item, idx) => {
        const isActive = active === item.key;
        return (
          <button
            key={item.key}
            type="button"
            onClick={() => onSelect(isActive ? "all" : item.key)}
            onMouseEnter={() => setHover(item.key)}
            onMouseLeave={() => setHover(null)}
            className="group grid grid-cols-[minmax(0,1fr)_auto] items-center gap-3 border-b border-rule py-2 text-left transition-colors last:border-b-0 hover:bg-paper2/70 dark:border-microrule dark:hover:bg-micro2/70"
            aria-pressed={isActive}
          >
            <div className="min-w-0">
              <div className="flex items-baseline gap-2">
                <span className="num text-[10px] text-warm dark:text-bone/45">
                  {String(idx + 1).padStart(2, "0")}
                </span>
                <span
                  className={`truncate text-[12px] font-semibold tracking-tight ${
                    isActive ? "text-ink dark:text-bone" : "text-ink/80 dark:text-bone/75"
                  }`}
                  title={item.label}
                >
                  {item.label}
                </span>
              </div>
              <div className="mt-1.5 h-[7px] w-full bg-rule/60 dark:bg-microrule/70">
                <div
                  className="h-full"
                  style={{
                    width: `${(item.value / max) * 100}%`,
                    background: item.color,
                    opacity: isActive || hover === item.key ? 1 : 0.82,
                    transition: "width .7s cubic-bezier(.22,1,.36,1), opacity .25s ease",
                  }}
                />
              </div>
            </div>
            <div className="text-right">
              <div className="num text-[12px] font-semibold text-ink dark:text-bone">
                {format(item.value)}
              </div>
              <div className="num text-[10px] text-warm dark:text-bone/45">
                {(item.share * 100).toFixed(1)}%
              </div>
            </div>
          </button>
        );
      })}
    </div>
  );
}

/* --------------------------------- donut --------------------------------- */

function arcPath(cx: number, cy: number, rOut: number, rIn: number, a0: number, a1: number) {
  const large = a1 - a0 > Math.PI ? 1 : 0;
  const pt = (r: number, a: number) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];
  const [x0, y0] = pt(rOut, a0);
  const [x1, y1] = pt(rOut, a1);
  const [x2, y2] = pt(rIn, a1);
  const [x3, y3] = pt(rIn, a0);
  return `M${x0.toFixed(2)},${y0.toFixed(2)} A${rOut},${rOut} 0 ${large} 1 ${x1.toFixed(2)},${y1.toFixed(2)} L${x2.toFixed(2)},${y2.toFixed(2)} A${rIn},${rIn} 0 ${large} 0 ${x3.toFixed(2)},${y3.toFixed(2)} Z`;
}

export function DonutChart({
  items,
  format,
  centerLabel,
  centerValue,
}: {
  items: { key: string; label: string; value: number; color: string; share: number }[];
  format: (n: number) => string;
  centerLabel: string;
  centerValue: string;
}) {
  const [hover, setHover] = useState<string | null>(null);
  const [entered, setEntered] = useState(false);
  useEffect(() => {
    const id = window.setTimeout(() => setEntered(true), 60);
    return () => window.clearTimeout(id);
  }, []);

  const angles: { key: string; a0: number; a1: number }[] = [];
  let cursor = -Math.PI / 2;
  items.forEach((it) => {
    const sweep = it.share * Math.PI * 2;
    angles.push({ key: it.key, a0: cursor, a1: cursor + sweep });
    cursor += sweep;
  });

  const active = items.find((i) => i.key === hover) ?? null;

  return (
    <div className="relative mx-auto w-full max-w-[320px]" style={{ aspectRatio: "1 / 1" }}>
      <svg viewBox="0 0 200 200" className="h-full w-full">
        <circle cx="100" cy="100" r="92" fill="none" className="stroke-rule dark:stroke-microrule" strokeWidth="1" />
        {items.map((it, i) => {
          const a = angles[i];
          const mid = (a.a0 + a.a1) / 2;
          const isHover = hover === it.key;
          const offset = isHover ? 7 : 0;
          return (
            <path
              key={it.key}
              d={arcPath(100, 100, 88, 58, a.a0, a.a1 - 0.012)}
              fill={it.color}
              opacity={entered ? (hover === null || isHover ? 1 : 0.34) : 0}
              transform={`translate(${(Math.cos(mid) * offset).toFixed(2)},${(Math.sin(mid) * offset).toFixed(2)})`}
              style={{
                transition:
                  "opacity .35s ease, transform .35s cubic-bezier(.22,1,.36,1)",
                cursor: "pointer",
              }}
              onMouseEnter={() => setHover(it.key)}
              onMouseLeave={() => setHover(null)}
            />
          );
        })}
      </svg>

      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center px-10 text-center">
        <div className="tracked text-[9px] text-warm dark:text-bone/50">
          {active ? active.label : centerLabel}
        </div>
        <div className="num mt-1 text-[20px] font-semibold text-ink dark:text-bone">
          {active ? format(active.value) : centerValue}
        </div>
                <div className="num text-[10px] text-warm dark:text-bone/50">
                  {active ? `${(active.share * 100).toFixed(1)}% of reported loss` : "reported loss"}
                </div>
      </div>
    </div>
  );
}

export function LegendList({
  items,
  format,
  onSelect,
}: {
  items: { key: string; label: string; value: number; color: string; share: number }[];
  format: (n: number) => string;
  onSelect?: (key: string) => void;
}) {
  return (
    <ul className="mt-4 space-y-1.5">
      {items.map((it) => (
        <li key={it.key}>
          <button
            type="button"
            onClick={() => onSelect?.(it.key)}
            className="flex w-full items-center gap-2 text-left transition-opacity hover:opacity-70"
          >
            <span className="h-2.5 w-2.5 shrink-0" style={{ background: it.color }} />
            <span className="min-w-0 flex-1 truncate text-[11px] text-ink/80 dark:text-bone/70">
              {it.label}
            </span>
            <span className="num shrink-0 text-[11px] font-semibold text-ink dark:text-bone">
              {format(it.value)}
            </span>
            <span className="num w-11 shrink-0 text-right text-[10px] text-warm dark:text-bone/45">
              {(it.share * 100).toFixed(1)}%
            </span>
          </button>
        </li>
      ))}
    </ul>
  );
}
