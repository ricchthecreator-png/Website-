import { Dashboard } from "./components/Dashboard";
import { Recovery } from "./components/Recovery";
import { Seal, Wordmark } from "./components/Seal";
import { useDarkMode, useReveal } from "./lib/hooks";

const NAV = [
  { href: "#data", label: "Data room" },
  { href: "#recovery", label: "Asset recovery" },
  { href: "#intake", label: "File a complaint" },
];

function Hero() {
  const ref = useReveal<HTMLDivElement>();
  return (
    <section className="relative overflow-hidden bg-ink">
      <img
        src="images/desk.jpg"
        alt="A fraud investigator's desk at night: case folders, wire records and a rubber stamp under a brass lamp"
        className="absolute inset-0 h-full w-full object-cover object-[70%_center] opacity-90"
      />
      <div className="absolute inset-0 bg-gradient-to-r from-micro via-micro/88 to-micro/25" />
      <div className="absolute inset-0 bg-gradient-to-t from-micro via-transparent to-micro/40" />

      <div className="relative mx-auto flex min-h-[86vh] max-w-[1400px] flex-col justify-end px-5 pt-24 pb-14 sm:px-8 sm:pt-32">
        <div ref={ref} className="reveal grid grid-cols-1 items-end gap-12 lg:grid-cols-12">
          <div className="lg:col-span-7">
            <div className="tracked flex flex-wrap items-center gap-x-3 gap-y-1 text-[9px] font-semibold text-gold">
              <span>Annual data room</span>
              <span className="text-bone/35">·</span>
              <span className="text-bone/70">25 years of internet crime reporting</span>
              <span className="text-bone/35">·</span>
              <span className="text-bone/70">220 countries of origin</span>
            </div>

            <h1 className="mt-6 font-serif text-[42px] leading-[0.94] font-light text-bone sm:text-[68px] lg:text-[82px]">
              Every complaint is a ledger entry.
              <span className="block italic text-gold">Every dollar has a trail.</span>
            </h1>

            <p className="mt-7 max-w-[58ch] text-[14px] leading-[1.85] text-bone/70 sm:text-[16px]">
              The Internet Crime Complaints Commission tracks fraud reported from around the world — and runs the
              bureau that traces stolen funds, freezes them where it can, and returns them to the people who lost
              them. Live figures below; the recovery desk is one scroll further down.
            </p>

            <div className="mt-9 flex flex-wrap items-center gap-3">
              <a
                href="#data"
                className="tracked border border-gold bg-gold px-7 py-4 text-[9px] font-semibold text-ink transition-colors hover:bg-transparent hover:text-gold"
              >
                Open the data room
              </a>
              <a
                href="#intake"
                className="tracked border border-bone/35 px-7 py-4 text-[9px] font-semibold text-bone transition-colors hover:border-bone hover:bg-bone hover:text-micro"
              >
                File a complaint
              </a>
            </div>
          </div>

          {/* receipt panel */}
          <aside className="relative lg:col-span-5">
            <div className="grain relative border border-gold/40 bg-paper p-6 shadow-[0_30px_80px_-30px_rgba(0,0,0,.7)] sm:p-8">
              <div className="flex items-start justify-between border-b border-dashed border-rule pb-4">
                <div>
                  <div className="tracked text-[9px] font-semibold text-warm">Statement of record</div>
                  <div className="num mt-1 text-[11px] text-ink/70">FY2024 · IC3 annual return</div>
                </div>
                <Seal size={48} />
              </div>

              <dl className="mt-5 space-y-4">
                {[
                  { k: "Complaints received", v: "859,532", note: "highest volume on record" },
                  { k: "Reported losses", v: "$16.6B", note: "+33% year over year" },
                  { k: "Victims aged 60+", v: "$4.88B", note: "147,127 complaints filed" },
                ].map((row) => (
                  <div key={row.k} className="flex items-end justify-between gap-4">
                    <div>
                      <dt className="tracked text-[9px] text-warm">{row.k}</dt>
                      <dd className="num mt-1 text-[30px] leading-none font-semibold text-ink sm:text-[36px]">
                        {row.v}
                      </dd>
                    </div>
                    <div className="text-right text-[10px] leading-tight text-warm">{row.note}</div>
                  </div>
                ))}
              </dl>

              <div className="mt-6 border-t border-dashed border-rule pt-4">
                <p className="text-[11px] leading-relaxed text-warm">
                  Cryptocurrency featured in <span className="num text-ink">149,686</span> complaints and{" "}
                  <span className="num text-ink">$9.32B</span> of losses. Wire recall remains the single most
                  effective intervention the Bureau can make.
                </p>
                  <div className="tracked mt-4 flex items-center justify-between text-[9px] text-warm">
                  <span>Verified against public filings</span>
                  <span className="num text-goldink">ICCC/AR/2026-01</span>
                </div>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </section>
  );
}

function Masthead({ dark, setDark }: { dark: boolean; setDark: (v: boolean) => void }) {
  return (
    <header className="relative z-40 border-b border-ink/15 bg-paper dark:border-microrule dark:bg-micro">
      <div className="mx-auto flex max-w-[1400px] items-center justify-between gap-6 px-5 py-4 sm:px-8">
        <a href="#top" className="flex items-center gap-3">
          <Seal size={46} ink={dark ? "#ede7da" : "#0f2440"} />
          <Wordmark ink={dark ? "#ede7da" : "#0f2440"} accent={dark ? "#b08328" : "#8a6318"} />
        </a>

        <nav className="hidden items-center gap-7 lg:flex">
          {NAV.map((n) => (
            <a
              key={n.href}
              href={n.href}
              className="tracked text-[9px] font-semibold text-ink transition-colors hover:text-gold dark:text-bone/80 dark:hover:text-gold"
            >
              {n.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <div className="flex items-center border border-ink/20 dark:border-bone/20">
            <button
              type="button"
              onClick={() => setDark(false)}
              className={`tracked px-2.5 py-2 text-[8px] font-semibold transition-colors ${
                !dark ? "bg-ink text-paper dark:bg-bone dark:text-micro" : "text-ink/70 dark:text-bone/55"
              }`}
              aria-pressed={!dark}
            >
              Daylight
            </button>
            <button
              type="button"
              onClick={() => setDark(true)}
              className={`tracked px-2.5 py-2 text-[8px] font-semibold transition-colors ${
                dark ? "bg-ink text-paper dark:bg-bone dark:text-micro" : "text-ink/70 dark:text-bone/55"
              }`}
              aria-pressed={dark}
            >
              Microfilm
            </button>
          </div>
          <a
            href="#intake"
            className="tracked hidden border border-gold bg-gold px-4 py-2.5 text-[9px] font-semibold text-ink transition-colors hover:bg-transparent hover:text-gold sm:inline-block"
          >
            File a complaint
          </a>
        </div>
      </div>
    </header>
  );
}

function Footer() {
  return (
    <footer className="border-t border-bone/15 bg-ink text-bone">
      <div className="mx-auto max-w-[1400px] px-5 py-14 sm:px-8">
        <div className="grid grid-cols-1 gap-10 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <div className="flex items-center gap-3">
              <Seal size={56} ink="#ede7da" gold="#b08328" />
              <Wordmark ink="#ede7da" sub="Bureau of Repatriation" />
            </div>
            <p className="mt-6 max-w-[52ch] text-[11.5px] leading-[1.9] text-bone/60">
              The Internet Crime Complaints Commission is the national reporting centre for cyber-enabled fraud and
              the office responsible for tracing and repatriating stolen funds. Complaint data is used for law
              enforcement purposes only. Figures shown in this data room are modelled on published annual reporting
              and refreshed daily at 06:00 UTC.
            </p>
          </div>

          <div className="grid grid-cols-2 gap-8 lg:col-span-7 lg:grid-cols-3">
            {[
              {
                title: "Data room",
                links: ["Annual report 2025", "Category taxonomy", "Methodology note", "Open data (CSV)"],
              },
              {
                title: "Recovery bureau",
                links: ["How tracing works", "Freezing orders", "Mutual legal assistance", "Restitution register"],
              },
              {
                title: "For victims",
                links: ["File a complaint", "Recovery scam warning", "Victim support partners", "Contact the Bureau"],
              },
            ].map((col) => (
              <div key={col.title}>
                <div className="tracked text-[9px] font-semibold text-gold">{col.title}</div>
                <ul className="mt-4 space-y-2.5">
                  {col.links.map((l) => (
                    <li key={l}>
                      <a
                        href="#intake"
                        className="text-[11.5px] text-bone/65 transition-colors hover:text-gold"
                      >
                        {l}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-12 flex flex-wrap items-center justify-between gap-4 border-t border-bone/15 pt-6">
          <div className="num text-[10px] text-bone/45">
            © 2026 INTERNET CRIME COMPLAINTS COMMISSION · DATA ROOM BUILD 2026.1
          </div>
          <div className="tracked flex flex-wrap items-center gap-x-5 gap-y-2 text-[9px] text-bone/45">
            <span>Privacy</span>
            <span>Accessibility</span>
            <span>FOIA</span>
            <span className="text-gold">fraud@iccc.gov</span>
          </div>
        </div>
      </div>
    </footer>
  );
}

export default function App() {
  const { dark, setDark } = useDarkMode();

  return (
    <div id="top" className="min-h-screen bg-paper transition-colors duration-300 dark:bg-micro">
      {/* fixed vertical rail */}
      <div className="fixed top-0 left-0 z-50 hidden h-full w-14 flex-col items-center justify-between border-r border-ink/15 bg-paper py-6 xl:flex dark:border-microrule dark:bg-micro">
        <Seal size={32} ink={dark ? "#ede7da" : "#0f2440"} gold={dark ? "#b08328" : "#b08328"} />
        <div className="tracked text-[9px] font-semibold whitespace-nowrap text-ink/70 dark:text-bone/60" style={{ writingMode: "vertical-rl", transform: "rotate(180deg)" }}>
          Internet Crime Complaints Commission · Annual Data Room 2025
        </div>
        <div className="num text-[9px] text-gold">26</div>
      </div>

      <div className="xl:pl-14">
        <Masthead dark={dark} setDark={setDark} />
        <Hero />
        <Dashboard />
        <Recovery />
        <Footer />
      </div>
    </div>
  );
}
