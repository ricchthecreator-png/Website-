/* ------------------------------------------------------------------
   Internet Crime Complaints Commission — synthetic but grounded dataset.
   Annual complaint / loss totals follow published IC3 annual report
   figures for 2019-2024; 2025 is a modelled extension. Monthly splits,
   category drifts and recovery rates are generated with a seeded PRNG so
   every chart is alive but fully deterministic across reloads.
------------------------------------------------------------------- */

function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export interface TypeDef {
  key: string;
  label: string;
  short: string;
  color: string;
  /** 2024 complaint count (IC3-aligned) */
  complaints: number;
  /** 2024 reported loss, USD billions */
  losses: number;
  /** annual share drift, e.g. +0.12 = category grows 12%/yr */
  drift: number;
  /** share of losses traced & returned to victims */
  recovery: number;
  /** median loss = mean loss * medianMult */
  medianMult: number;
}

export const TYPES: TypeDef[] = [
  { key: "investment", label: "Investment & Ponzi Schemes", short: "Investment", color: "#0f2440", complaints: 47919, losses: 6.57, drift: 0.14, recovery: 0.083, medianMult: 0.42 },
  { key: "bec", label: "Business Email Compromise", short: "BEC", color: "#b08328", complaints: 31200, losses: 2.77, drift: 0.07, recovery: 0.286, medianMult: 0.71 },
  { key: "breach", label: "Personal Data Breach", short: "Data Breach", color: "#9e2b25", complaints: 64882, losses: 1.5, drift: -0.02, recovery: 0.121, medianMult: 0.33 },
  { key: "tech", label: "Tech Support Fraud", short: "Tech Support", color: "#4a6b8a", complaints: 60000, losses: 1.46, drift: 0.05, recovery: 0.164, medianMult: 0.48 },
  { key: "romance", label: "Confidence & Romance", short: "Romance", color: "#7a5c3e", complaints: 60000, losses: 0.92, drift: 0.03, recovery: 0.062, medianMult: 0.55 },
  { key: "nonpay", label: "Non-Payment / Non-Delivery", short: "Non-Payment", color: "#6e6a60", complaints: 49572, losses: 0.79, drift: -0.05, recovery: 0.212, medianMult: 0.26 },
  { key: "gov", label: "Government Impersonation", short: "Gov. Impersonation", color: "#2f6b4f", complaints: 60000, losses: 0.62, drift: 0.02, recovery: 0.188, medianMult: 0.39 },
  { key: "card", label: "Credit Card / Account Fraud", short: "Card Fraud", color: "#c2652f", complaints: 110000, losses: 0.31, drift: -0.06, recovery: 0.342, medianMult: 0.21 },
  { key: "extortion", label: "Extortion & Sextortion", short: "Extortion", color: "#5b4b8a", complaints: 86415, losses: 0.53, drift: 0.09, recovery: 0.147, medianMult: 0.24 },
  { key: "identity", label: "Identity Theft", short: "Identity Theft", color: "#8c6f9e", complaints: 70500, losses: 0.42, drift: 0.01, recovery: 0.173, medianMult: 0.29 },
  { key: "lottery", label: "Sweepstakes & Lottery", short: "Lottery", color: "#a8927a", complaints: 22600, losses: 0.32, drift: -0.03, recovery: 0.091, medianMult: 0.52 },
  { key: "phishing", label: "Phishing & Spoofing", short: "Phishing", color: "#2d6a7a", complaints: 193407, losses: 0.28, drift: -0.04, recovery: 0.229, medianMult: 0.18 },
  { key: "ransomware", label: "Ransomware", short: "Ransomware", color: "#b8452f", complaints: 3037, losses: 0.11, drift: 0.11, recovery: 0.243, medianMult: 0.88 },
];

export const YEARS = [2019, 2020, 2021, 2022, 2023, 2024, 2025];

/** Published IC3 annual figures (2025 modelled). */
export const ANCHORS: Record<number, { complaints: number; losses: number }> = {
  2019: { complaints: 467361, losses: 3.52 },
  2020: { complaints: 791790, losses: 4.2 },
  2021: { complaints: 847376, losses: 6.92 },
  2022: { complaints: 800944, losses: 10.3 },
  2023: { complaints: 880418, losses: 12.5 },
  2024: { complaints: 859532, losses: 16.6 },
  2025: { complaints: 921447, losses: 19.42 },
};

export interface Row {
  year: number;
  month: number;
  key: string;
  complaints: number;
  losses: number;
  recovered: number;
}

function categoryWeights(year: number, field: "complaints" | "losses") {
  const raw = TYPES.map((t) => {
    const base = field === "complaints" ? t.complaints : t.losses;
    return base * Math.pow(1 + t.drift, year - 2024);
  });
  const sum = raw.reduce((a, b) => a + b, 0);
  return raw.map((v) => v / sum);
}

function buildRows(): Row[] {
  const rows: Row[] = [];
  const recoveryTrend: Record<number, number> = {
    2019: 0.78,
    2020: 0.84,
    2021: 0.9,
    2022: 0.96,
    2023: 1.0,
    2024: 1.08,
    2025: 1.16,
  };
  YEARS.forEach((year, yi) => {
    const cw = categoryWeights(year, "complaints");
    const lw = categoryWeights(year, "losses");
    TYPES.forEach((t, ti) => {
      const rnd = mulberry32(year * 1000 + ti * 37 + 7);
      const annualC = ANCHORS[year].complaints * cw[ti];
      const annualL = ANCHORS[year].losses * 1e9 * lw[ti];
      const phase = (ti / TYPES.length) * Math.PI * 2;
      const weights: number[] = [];
      for (let m = 0; m < 12; m++) {
        const season = 1 + 0.16 * Math.sin((m / 12) * Math.PI * 2 + phase);
        const noise = 0.88 + rnd() * 0.26;
        const trend = 1 + (m / 11) * (0.04 * (yi - 3) * 0.35);
        weights.push(season * noise * trend);
      }
      const wsum = weights.reduce((a, b) => a + b, 0);
      for (let m = 0; m < 12; m++) {
        const share = weights[m] / wsum;
        const losses = annualL * share;
        const complaints = annualC * share;
        const recovNoise = 0.82 + rnd() * 0.34;
        rows.push({
          year,
          month: m,
          key: t.key,
          complaints,
          losses,
          recovered: losses * t.recovery * recoveryTrend[year] * recovNoise,
        });
      }
    });
  });
  return rows;
}

export const ROWS: Row[] = buildRows();

/* ---------------------------- segments ---------------------------- */

export const REGIONS = [
  { key: "northeast", label: "Northeast", loss: 0.18, complaints: 0.17 },
  { key: "south", label: "South", loss: 0.34, complaints: 0.33 },
  { key: "midwest", label: "Midwest", loss: 0.15, complaints: 0.16 },
  { key: "west", label: "West", loss: 0.27, complaints: 0.28 },
  { key: "international", label: "International", loss: 0.06, complaints: 0.06 },
];

export const AGES = [
  { key: "u20", label: "Under 20", loss: 0.01, complaints: 0.05 },
  { key: "20s", label: "20 – 29", loss: 0.09, complaints: 0.16 },
  { key: "30s", label: "30 – 39", loss: 0.19, complaints: 0.21 },
  { key: "40s", label: "40 – 49", loss: 0.19, complaints: 0.19 },
  { key: "50s", label: "50 – 59", loss: 0.15, complaints: 0.16 },
  { key: "60plus", label: "60 and over", loss: 0.37, complaints: 0.23 },
];

export interface Filters {
  from: number;
  to: number;
  type: string;
  region: string;
  age: string;
}

export interface Point {
  label: string;
  key: string;
  value: number;
  secondary: number;
  tertiary: number;
}

export interface Aggregate {
  complaints: number;
  losses: number;
  recovered: number;
  recoveryRate: number;
  avgLoss: number;
  medianLoss: number;
  monthly: Point[];
  byType: { key: string; label: string; short: string; color: string; value: number; complaints: number; recovered: number; share: number }[];
  byAge: { key: string; label: string; value: number; share: number }[];
  byRegion: { key: string; label: string; value: number; share: number }[];
  rows: {
    id: string;
    year: number;
    type: string;
    typeLabel: string;
    color: string;
    complaints: number;
    losses: number;
    median: number;
    recovered: number;
    rate: number;
    yoy: number;
  }[];
}

const MONTH_ABBR = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function typeByKey(k: string) {
  return TYPES.find((t) => t.key === k)!;
}

export function aggregate(f: Filters): Aggregate {
  const region = REGIONS.find((r) => r.key === f.region);
  const age = AGES.find((a) => a.key === f.age);
  const lossFactor = (region ? region.loss : 1) * (age ? age.loss : 1);
  const compFactor = (region ? region.complaints : 1) * (age ? age.complaints : 1);

  const inRange = ROWS.filter(
    (r) => r.year >= f.from && r.year <= f.to && (f.type === "all" || r.key === f.type),
  );

  let complaints = 0;
  let losses = 0;
  let recovered = 0;
  const monthMap = new Map<string, Point>();
  const typeMap = new Map<string, { c: number; l: number; r: number }>();
  const yrType = new Map<string, { c: number; l: number; r: number }>();

  inRange.forEach((r) => {
    const l = r.losses * lossFactor;
    const c = r.complaints * compFactor;
    const rec = r.recovered * lossFactor;
    complaints += c;
    losses += l;
    recovered += rec;

    const mk = `${r.year}-${String(r.month).padStart(2, "0")}`;
    const mp = monthMap.get(mk) ?? {
      key: mk,
      label: `${MONTH_ABBR[r.month]} ${String(r.year).slice(2)}`,
      value: 0,
      secondary: 0,
      tertiary: 0,
    };
    mp.value += l;
    mp.secondary += c;
    mp.tertiary += rec;
    monthMap.set(mk, mp);

    const t = typeMap.get(r.key) ?? { c: 0, l: 0, r: 0 };
    t.c += c;
    t.l += l;
    t.r += rec;
    typeMap.set(r.key, t);

    const yk = `${r.year}|${r.key}`;
    const y = yrType.get(yk) ?? { c: 0, l: 0, r: 0 };
    y.c += c;
    y.l += l;
    y.r += rec;
    yrType.set(yk, y);
  });

  const monthly = Array.from(monthMap.values()).sort((a, b) => a.key.localeCompare(b.key));

  const byType = Array.from(typeMap.entries())
    .map(([key, v]) => {
      const t = typeByKey(key);
      return {
        key,
        label: t.label,
        short: t.short,
        color: t.color,
        value: v.l,
        complaints: v.c,
        recovered: v.r,
        share: losses > 0 ? v.l / losses : 0,
      };
    })
    .sort((a, b) => b.value - a.value);

  const totalLoss = losses || 1;
  const byAge = AGES.map((a) => ({
    key: a.key,
    label: a.label,
    value: totalLoss * (age ? (a.key === age.key ? 1 : 0) : a.loss),
    share: age ? (a.key === age.key ? 1 : 0) : a.loss,
  })).filter((d) => d.value > 0);

  const byRegion = REGIONS.map((r) => ({
    key: r.key,
    label: r.label,
    value: totalLoss * (region ? (r.key === region.key ? 1 : 0) : r.loss),
    share: region ? (r.key === region.key ? 1 : 0) : r.loss,
  })).filter((d) => d.value > 0);

  const rows = Array.from(yrType.entries())
    .map(([yk, v]) => {
      const [yearStr, key] = yk.split("|");
      const year = Number(yearStr);
      const t = typeByKey(key);
      const prev = yrType.get(`${year - 1}|${key}`);
      return {
        id: yk,
        year,
        type: key,
        typeLabel: t.label,
        color: t.color,
        complaints: v.c,
        losses: v.l,
        median: v.c > 0 ? (v.l / v.c) * t.medianMult : 0,
        recovered: v.r,
        rate: v.l > 0 ? v.r / v.l : 0,
        yoy: prev && prev.l > 0 ? (v.l - prev.l) / prev.l : 0,
      };
    })
    .sort((a, b) => b.losses - a.losses);

  return {
    complaints,
    losses,
    recovered,
    recoveryRate: losses > 0 ? recovered / losses : 0,
    avgLoss: complaints > 0 ? losses / complaints : 0,
    medianLoss:
      complaints > 0
        ? byType.reduce((sum, t) => sum + (t.complaints > 0 ? (t.value / t.complaints) * 0.4 : 0) * t.complaints, 0) /
          Math.max(1, complaints)
        : 0,
    monthly,
    byType,
    byAge,
    byRegion,
    rows,
  };
}

/** The comparison window used for every trend arrow. */
export function previousFilters(f: Filters): Filters {
  const span = f.to - f.from + 1;
  if (f.from - span >= YEARS[0]) return { ...f, from: f.from - span, to: f.from - 1 };
  return { ...f, from: Math.max(YEARS[0], f.from - 1), to: Math.max(YEARS[0], f.to - 1) };
}

export function trendOf(current: number, previous: number) {
  if (!previous) return 0;
  return (current - previous) / previous;
}

/* ---------------------------- formatting ---------------------------- */

export function fmtMoney(n: number, digits = 2) {
  const abs = Math.abs(n);
  if (abs >= 1e9) return `$${(n / 1e9).toFixed(digits)}B`;
  if (abs >= 1e6) return `$${(n / 1e6).toFixed(abs >= 1e7 ? 1 : 2)}M`;
  if (abs >= 1e3) return `$${(n / 1e3).toFixed(0)}K`;
  return `$${n.toFixed(0)}`;
}

export function fmtMoneyFull(n: number) {
  return `$${Math.round(n).toLocaleString("en-US")}`;
}

export function fmtNum(n: number) {
  return Math.round(n).toLocaleString("en-US");
}

export function fmtPct(n: number, digits = 1) {
  return `${(n * 100).toFixed(digits)}%`;
}
